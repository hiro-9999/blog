new Vue({
  el: '#app',
  data: {
    attrs: {
      size: 20,
      maxlength: 14,
      required: true
    }
  }
});