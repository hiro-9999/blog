new Vue({
  el: '#app',
  data: {
    os: ['Windows', 'macOS']
  }
});