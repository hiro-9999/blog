new Vue({
  el: '#app',
  data: {
    attr: 'width',
    size: 100
  },
});