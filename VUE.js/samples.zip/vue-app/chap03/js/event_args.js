new Vue({
  el: '#app',
  methods: {
    onclick: function(message) {
      console.log(message);
    }
  }
});