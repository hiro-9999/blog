new Vue({
  el: '#app',
  methods: {
    onclick: function(e) {
      console.log(e)
    }
  }
});