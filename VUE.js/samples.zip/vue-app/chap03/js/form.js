new Vue({
  el: '#app',
  data: {
    myName: '匿名'
  }
});