new Vue({
  el: '#app',
  data: {
    colorClass: 'color',
    isChange: true
  }
})