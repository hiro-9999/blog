new Vue({
  el: '#app',
  data: {
    colorClass: 'color',
    frameClass: 'frame'
  }
})