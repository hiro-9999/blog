new Vue({
  el: '#app',
  data: {
    show: true
  }
});