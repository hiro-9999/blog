new Vue({
  el: '#app',
  data: {
    message: `<h3>WINGSプロジェクト</h3>
    <img src="https://www.web-deli.com/image/linkbanner_l.gif" alt="ロゴ" />`
  }
});