new Vue({
  el: '#app',
  data: {
    agree : true
  }
});