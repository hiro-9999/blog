new Vue({
  el: '#app',
  data: {
    text: '皆さん、こんにちは！'
  }
});