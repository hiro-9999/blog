new Vue({
  el: '#app',
  data: {
    pay: 'credit'
  }
});