new Vue({
  el: '#app',
  data: {
    pet: 'いぬ'
  }
});