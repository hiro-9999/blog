new Vue({
  el: '#app',
  data: {
    color: {
      backgroundColor: 'Aqua',
      color: 'Red'
    },
    size: {
      fontSize: '1.5em'
    }
  }
})