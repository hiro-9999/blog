new Vue({
  el: '#app',
  data: {
    os: ''
  }
});