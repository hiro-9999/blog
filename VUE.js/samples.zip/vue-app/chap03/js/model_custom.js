new Vue({
  el: '#app',
  data: {
    mails: [],
  }
});
