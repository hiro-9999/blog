new Vue({
  el: '#app',
  data: {
    name: '匿名'
  }
});