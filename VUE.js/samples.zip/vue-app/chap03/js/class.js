new Vue({
  el: '#app',
  data: {
    color: true,
    isChange: true,
  }
})