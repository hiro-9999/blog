Vue.use(VeeValidate, { locale: 'ja', fastExit: false });

new Vue({
  el: '#app'
});