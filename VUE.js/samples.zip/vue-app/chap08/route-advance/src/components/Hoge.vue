<template>
  <div>
    <p>あ</p>
    <p>い</p>
    <p>う</p>
    <p>え</p>
    <p>お</p>
    <p>か</p>
    <p>き</p>
    <p>く</p>
    <p>け</p>
    <p>こ</p>
    <p id="sa">さ</p>
    <p>し</p>
    <p>す</p>
    <p>せ</p>
    <p>そ</p>
    <p>た</p>
    <p>ち</p>
    <p>つ</p>
    <p>て</p>
    <p>と</p>
    <router-link to="/about">About</router-link>
  </div>
</template>