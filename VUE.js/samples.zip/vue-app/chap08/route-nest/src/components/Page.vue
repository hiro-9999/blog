<template>
  <div>{{ page_num }} ページ</div>
</template>

<script>
export default {
  props: {	
    page_num: String
  }
}
</script>