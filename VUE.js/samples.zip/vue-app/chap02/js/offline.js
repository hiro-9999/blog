new Vue({
  el: '#app',
  data: {
    message: '皆さん、こんにちは！'
  }
});