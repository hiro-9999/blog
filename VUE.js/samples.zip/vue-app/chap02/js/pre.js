new Vue({
  el: '#app',
  data: {
    message: 'こんにちは、世界！'
  }
});