new Vue({
  el: '#app',
  data: {
    url: 'https://wings.msn.to/'
  }
});