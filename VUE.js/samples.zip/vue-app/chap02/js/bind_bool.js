new Vue({
  el: '#app',
  data: {
    flag: true
  }
});