new Vue({
  el: '#app',
  data: {
    email: 'Y-Suzuki@example.com'
  }
});