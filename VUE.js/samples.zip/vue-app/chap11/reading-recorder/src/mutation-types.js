export const UPDATE_CURRENT = 'updateCurrent';
export const UPDATE_BOOK = 'updateBook';
