# DIP_sample
DIP(依存性逆転の原則)のサンプルコードです。
下記リンク先のQiitaの記事にてDIPについてこのコードを用いて詳しく説明しています。
https://qiita.com/masalennon/items/989732cc9918bac7cba5
